# TODO

- [ ] Change options class to be `Literal` type
  - [ ] Literals are processed specially for options or as what the config value should `literally` be.
- [ ] Allow for typing package types
